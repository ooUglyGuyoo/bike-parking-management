# bike detect > 2024-05-22 12:54pm
https://universe.roboflow.com/workspace-tcmrx/bike-detect-rh71v

Provided by a Roboflow user
License: CC BY 4.0

